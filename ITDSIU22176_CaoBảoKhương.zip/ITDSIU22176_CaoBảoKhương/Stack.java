public class Stack<T> {
    private int maxSize;
    private int top;
    private T[] arr;

    // Constructor
    @SuppressWarnings("unchecked")
    public Stack(int size) {
        this.maxSize = size;
        this.top = -1;
        this.arr = (T[]) new Object[maxSize]; 
    }

    // Add element to top
    public void push(T value) {
        if (isFull()) {
            System.out.println("Stack Full!");
            return;
        }
        arr[++top] = value;
    }

    // Remove and return top element
    public T pop() {
        if (isEmpty()) {
            System.out.println("Stack Empty!");
            return null;
        }
        return arr[top--];
    }

    // Return top element without removing
    public T peek() {
        if (isEmpty()) return null;
        return arr[top];
    }

    // Check if stack is full
    public boolean isFull() {
        return top == maxSize - 1;
    }

    // Check if stack is empty
    public boolean isEmpty() {
        return top == -1;
    }

    // Main for testing
    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>(5);
        
        stack.push(10);
        stack.push(20);
        
        System.out.println("Peek: " + stack.peek()); // Output: 20
        System.out.println("Pop: " + stack.pop());   // Output: 20
        System.out.println("Empty: " + stack.isEmpty()); // Output: false
    }
}